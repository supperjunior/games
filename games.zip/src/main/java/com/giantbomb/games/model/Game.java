package com.giantbomb.games.model;

public class Game {

    private String name;

    private String guid;

    private String description;

    private Image image;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Game{" +
                "name='" + name + '\'' +
                ", guid='" + guid + '\'' +
                ", image=" + image +
                '}';
    }
}
