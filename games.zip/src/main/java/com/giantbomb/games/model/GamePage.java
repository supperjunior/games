package com.giantbomb.games.model;

import java.util.List;

public class GamePage {
    private List<Game> games;

    private int pageNumber;

    private int totalPages;

    private int recordFrom;

    private int recordTo;

    public List<Game> getGames() {
        return games;
    }

    public void setGames(List<Game> games) {
        this.games = games;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getRecordFrom() {
        return recordFrom;
    }

    public void setRecordFrom(int recordFrom) {
        this.recordFrom = recordFrom;
    }

    public int getRecordTo() {
        return recordTo;
    }

    public void setRecordTo(int recordTo) {
        this.recordTo = recordTo;
    }

    @Override
    public String toString() {
        return "GamePage{" +
                "games=" + games +
                ", pageNumber=" + pageNumber +
                ", total=" + totalPages +
                ", recordFrom=" + recordFrom +
                ", recordTo=" + recordTo +
                '}';
    }
}
