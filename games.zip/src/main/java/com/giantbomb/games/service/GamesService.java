package com.giantbomb.games.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.giantbomb.games.model.Game;
import com.giantbomb.games.model.GamePage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GamesService {

    @Value("${application.giantbomb.api.baseurl}")
    private String baseUrl;

    @Value("${application.giantbomb.apikey}")
    private String apikey;

    ObjectMapper mapper;

    public GamesService() {
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    private HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("User-agent", "Chrome");
        return headers;
    }

    public GamePage getSearchResults(String query, Integer limit, Integer page) {
        GamePage gamePage = new GamePage();
        if (query == null || "".equals(query.trim())) {
            return gamePage;
        }
        String uri = baseUrl + "search?api_key={api_key}&format=json&resources=game&query={query}&limit={limit}&page={page}";
        Map<String, String> params = new HashMap<>();
        params.put("query", query);
        params.put("limit", String.valueOf(limit));
        params.put("page", String.valueOf(page));

        try {
            Map<String, Object> response = getResponseFromGaintBombApi(uri, params);
            if (response != null) {
                List<Game> results = mapObjectToGameList(response.get("results"));
                gamePage.setGames(results);
                gamePage.setPageNumber(page);
                int totalRecords = (Integer) response.getOrDefault("number_of_total_results", 0);
                int totalPages = (int) Math.ceil((totalRecords * 1.0) / limit);
                gamePage.setTotalPages(totalPages);
                gamePage.setPageNumber(page);
                gamePage.setRecordFrom(((Integer) response.getOrDefault("offset", -1)) + 1);
                gamePage.setRecordTo(((Integer) response.getOrDefault("number_of_page_results", -1)) + 1 + gamePage.getRecordFrom());
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return gamePage;
    }

    private Map<String, Object> getResponseFromGaintBombApi(String uri, Map<String, String> params) {
        params.put("api_key", apikey);
        ParameterizedTypeReference<HashMap<String, Object>> responseType =
                new ParameterizedTypeReference<HashMap<String, Object>>() {
                };
        HttpEntity<String> entity = new HttpEntity<>(getHeaders());
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<HashMap<String, Object>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, responseType, params);
        if (responseEntity != null && responseEntity.hasBody()) {
            Map<String, Object> response = responseEntity.getBody();
            return response;
        }
        return null;
    }

    public Game getGameDetails(String guid) {
        String uri = baseUrl + "game/{guid}?api_key={api_key}&format=json";
        System.out.println(uri);
        Map<String, String> params = new HashMap<>();
        params.put("guid", guid);

        try {
            Map<String, Object> response = getResponseFromGaintBombApi(uri, params);
            if (response != null) {
                Object results = response.get("results");
                try {
                    String json = mapper.writeValueAsString(results);
                    Game game = mapper.readValue(json, Game.class);
                    return game;
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return null;
    }

    private List<Game> mapObjectToGameList(Object object) {
        try {

            List<Object> objectList = (List<Object>) object;
            String json = mapper.writeValueAsString(objectList);
            Game[] games = mapper.readValue(json, Game[].class);
            return Arrays.asList(games);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return null;
    }
}
