package com.giantbomb.games.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Image {
    @JsonProperty("thumb_url")
    private String thumbnailUrl;

    @JsonProperty("screen_url")
    private String screenUrl;

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getScreenUrl() {
        return screenUrl;
    }

    public void setScreenUrl(String screenUrl) {
        this.screenUrl = screenUrl;
    }

    @Override
    public String toString() {
        return "Image{" +
                "thumbnailUrl='" + thumbnailUrl + '\'' +
                '}';
    }
}
