package com.giantbomb.games.controller;

import com.giantbomb.games.service.GamesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GamesController {

    @Autowired
    private GamesService gamesService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String showSearchPage(Model model,
                                 @RequestParam(name = "q", required = false) String query,
                                 @RequestParam(name = "limit", defaultValue = "10") Integer limit,
                                 @RequestParam(name = "page", defaultValue = "1") Integer page) {
        if (query != null && !"".equals(query.trim())) {
            model.addAttribute("query", query);
        }
        model.addAttribute("gamePage", gamesService.getSearchResults(query, limit, page));
        return "search";
    }

    @RequestMapping(value = "checkout/{guid}", method = RequestMethod.GET)
    public String showCheckoutPage(Model model,
                                   @PathVariable(name = "guid") String guid) {
        model.addAttribute("game", gamesService.getGameDetails(guid));
        return "checkout";
    }
}
